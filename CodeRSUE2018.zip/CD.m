function results=CD(res,N,T,W)
%disp(' ')
y_ni      = reshape(res,N,T)';
R         = corrcoef(y_ni) - diag(ones(N,1));
rho_h_ij  = sum(sum(triu(R))');
rho_h_bar = (2/(N*(N-1)))*rho_h_ij;
CD_stat   = sqrt(( T*N*(N-1))/2)*rho_h_bar; %27-2-2017 Replaced T for T-1
disp('Cross-Sectional Dependence (residuals)')
disp(['rho_hat_bar         ',num2str(rho_h_bar,'% 10.3f')])
disp(['CD statistic        ',num2str(CD_stat,'% 10.3f')])
results.CD=CD_stat;
results.R=R;
if nargin==4
ss_ij    = sum((sum(W'))')                     ;
CD_local = sqrt(T/ss_ij)*(sum((sum((R.*W)'))'));
disp(['CD_local statistic  ',num2str(CD_local,'% 10.3f')])
end

end