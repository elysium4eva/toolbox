function p = cols(x)
a=size(x);
p=a(2);