%
% J.Paul Elhorst, January 2017
% University of Groningen
% Department of Economics, Econometric and Finance
% 9700AV Groningen
% the Netherlands
% j.p.elhorst@rug.nl
%
% Reference: 
% Ciccarelli C., Elhorst J.P. (2017) A dynamic spatial econometric diffusion model with common factors: the rise and spread of cigarette consumption in Italy. 
% Regional Science and Urban Economics. http://www.sciencedirect.com/science/article/pii/S0166046216302435.
%
A=xlsread('fulldata1a.xls');
N=69; % number of spatial units
T=37; % number of time periods
fid=1;
y=A(:,16);
yunit=reshape(y,N,T);
% Unit root tests
display('unit root tests');
display('unit root test preferred model');
cips(yunit',N,T);
display('unit root test M1 M3 M4 M6 and another unconsidered model');
cips1(yunit',N,T);
x=[A(:,18) A(:,[17,19])];
display('unit root test M5');
cips2(yunit',x,N,T);
W1=xlsread('Distancematrix1.xlsx'); % To be activated in this file if interested.
wb = W1.^(-1.0)       ;  
for j=1:N
     wb(j,j) = 0;
end
W=xlsread('BC.xls');
W=normw(W);
CD(y,N,T,W);
for t=1:T
    t1=(t-1)*N+1;t2=t*N;
    wx(t1:t2,:)=W*x(t1:t2,:);
    Wy(t1:t2,1)=W*y(t1:t2,1);
end
[nobs K]=size(x);
xconstant=ones(nobs,1);
%
% Table 1: Column M1
%
init = ['y(t-1)      ';'Wy(t-1)     ';'logy        ';'logp        ';'educ        ';'W*logy      ';'W*y(t)      '];
info = struct('n',N,'t',T,'rmin',-1,'rmax',1,'lflag',0,'tl',1,'stl',1,'ted',1); %ted=1 or ted=2
results=sar_jihai_time(y(1:nobs),[x(N+1:nobs,:) wx(N+1:nobs,1)],W,info);
resultats = [results.theta results.theta1 results.tstat1];
[nr,~]    = size(resultats)                             ;
resul     = resultats(1:nr-1,:)                         ;
disp('Yu, de Jong and Lee (2008) ')
disp('(B-C means Bias-Corrected) ')
disp(' ')
disp('            Not B-C      B-C    t-stats')
disp([init,num2str(resul,'% 10.4f')])
disp(' ')
initstat=['R-squared   ';'R2 corrected';'LogL uncor  ';'LogLcorr    ';'sigma2      ';'sigma2 BC   '];
statistics=[results.rsqr results.corr2 results.lik results.lik1 results.theta(end) results.theta1(end)]'; 
disp([initstat,num2str(statistics,'% 15.4f')])
res= results.respaul1;
% CD(res,N-1,T-1,W); Local CD test can't be calculated in model with sfe and tfe
display(' ');
n=N-1;
y_ni      = reshape(res,n,T-1)'              ;
R         = corrcoef(y_ni) - diag(ones(n,1)) ;
rho_h_ij  = sum(sum(triu(R))')               ;
rho_h_bar = (2/(n*(n-1)))*rho_h_ij         ;
CD_stat   = sqrt(((T-1)*n*(n-1))/2)*rho_h_bar;
disp('Cross-Sectional Dependence (residuals)')
disp(['rho_hat_bar         ',num2str(rho_h_bar,'% 10.3f')])
disp(['CD statistic        ',num2str(CD_stat,'% 10.3f')])

btemp=results.theta1;
[npar dummy]=size(btemp);
varcov=results.varcov;
tau = results.theta1(1,1);
eta = results.theta1(2,1);
rho = results.theta1(npar-1,1);
varcov=results.varcov;
R=zeros(1,1);
R(1)=tau+rho+eta-1;
Rafg=zeros(1,npar);
Rafg(1,1)=1;Rafg(1,2)=1;Rafg(1,npar-1)=1;
sumpar=tau+rho+eta;
check=tau+rho+eta-1; % this should be negative
Wald=R(1)'*inv(Rafg(1,:)*varcov*Rafg(1,:)')*R(1);
F1=1-chis_cdf (Wald,1);
[sumpar check Wald F1]
VarR1=varcov(1,1)+varcov(2,2)+varcov(npar-1,npar-1)+varcov(1,2)+varcov(2,1)+...
      varcov(1,npar-1)+varcov(npar-1,1)+varcov(2,npar-1)+varcov(npar-1,2);
tval=R(1)/sqrt(VarR1)
R=zeros(1,1);
R(1)=btemp(2)+btemp(1)*btemp(npar-1);
Rafg=zeros(1,npar);
Rafg(1,1)=btemp(npar-1);Rafg(1,2)=1;Rafg(1,npar-1)=btemp(1);
Wald3=R(1)'*inv(Rafg(1,:)*varcov*Rafg(1,:)')*R(1);
F3=1-chis_cdf (Wald3,1);
[R(1) Wald3 F3]
%
% Direct and indirect effects estimates
% st=short term, lt=long term
% c=(long term) convergence effect of dependent variable
%
% Direct and indirect effects estimates
% st=short term, lt=long term
% c=(long term) convergence effect of dependent variable
%
NSIM=1000;
px=3;
simresults=zeros(npar-1,NSIM);
simdirst=zeros(px,NSIM);
simindst=zeros(px,NSIM);
simtotst=zeros(px,NSIM);
simdirlt=zeros(px,NSIM);
simindlt=zeros(px,NSIM);
simtotlt=zeros(px,NSIM);
simdirc=zeros(1,NSIM);
simindc=zeros(1,NSIM);
simtotc=zeros(1,NSIM);
for sim=1:NSIM
    parms = chol(varcov)'*randn(size(btemp)) + btemp;
    deltasim = parms(npar-1,1); % coef WY(t)
    betasim = parms(3:npar-2,1);
    tausim = parms(1,1); % Coef Y(t-1)
    etasim = parms(2,1); % Coef WY(t-1)
    simresults(:,sim)=[tausim;etasim;betasim;deltasim];
    SS=(eye(N)-deltasim*W)\eye(N);
    SC=SS*((tausim-1)*eye(N)+(deltasim+etasim)*W);
    simdirc(1,sim)=sum(diag(SC))/N; % average direct effect
    simindc(1,sim)=sum(sum(SC,2)-diag(SC))/N; % average indirect effect
    simtotc(1,sim)=simdirc(1,sim)+simindc(1,sim);
    for p=1:px
        C=zeros(N,N);
        for i=1:N
            for j=1:N
                if (i==j) C(i,j)=betasim(p);
                elseif (p<2) C(i,j)=betasim(p+px)*W(i,j);
                else C(i,j)=0;
                end
            end
        end
        SC=SS*C;
        simdirst(p,sim)=sum(diag(SC))/N; % average direct effect
        simindst(p,sim)=sum(sum(SC,2)-diag(SC))/N; % average indirect effect
        simtotst(p,sim)=simdirst(p,sim)+simindst(p,sim);
        SC=((1-tausim)*eye(N)-(deltasim+etasim)*W)\C;
        simdirlt(p,sim)=sum(diag(SC))/N; % average direct effect
        simindlt(p,sim)=sum(sum(SC,2)-diag(SC))/N; % average indirect effect
        simtotlt(p,sim)=simdirlt(p,sim)+simindlt(p,sim);        
    end
end
fprintf(1,'Convergence effect \n');
[mean(simdirc,2) mean(simdirc,2)./std(simdirc,0,2) mean(simindc,2) mean(simindc,2)./std(simindc,0,2)...
    mean(simtotc,2) mean(simtotc,2)./std(simtotc,0,2)]
fprintf(1,'Short term effects \n');
[mean(simdirst,2) mean(simdirst,2)./std(simdirst,0,2) mean(simindst,2) mean(simindst,2)./std(simindst,0,2)...
    mean(simtotst,2) mean(simtotst,2)./std(simtotst,0,2)]
fprintf(1,'Long term effects \n');
[mean(simdirlt,2) mean(simdirlt,2)./std(simdirlt,0,2) mean(simindlt,2) mean(simindlt,2)./std(simindlt,0,2)...
    mean(simtotlt,2) mean(simtotlt,2)./std(simtotlt,0,2)]
clear simresults simdirc simindc simtotc simdirst simindst simtotst simdirlt simindlt simtotlt;
%
%
% Common factors
%
%
ym=zeros(T,1);
xm=zeros(T,K);
yx=zeros(nobs,N);
x1=zeros(nobs,N);x2=zeros(nobs,N);x3=zeros(nobs,N);
for t=1:T
    t1=(t-1)*N+1;t2=t*N;
    ym(t)=mean(y(t1:t2));
    xm(t,:)=mean(x(t1:t2,:));
end
ysample=kron(ym,ones(N,1));
xsample=kron(xm,ones(N,1));
for t=1:T
    t1=(t-1)*N+1;t2=t*N;
    for i=1:N
        yx(t1-1+i,i)=ysample(t1-1+i,1);
        x1(t1-1+i,i)=xsample(t1-1+i,1);
        x2(t1-1+i,i)=xsample(t1-1+i,2);
        x3(t1-1+i,i)=xsample(t1-1+i,3);
    end
end
init = ['y(t-1)      ';'Wy(t-1)     ';
        'c-y(t)1     ';'c-y(t)2     ';'c-y(t)3     ';'c-y(t)4     ';'c-y(t)5     ';'c-y(t)6     ';'c-y(t)7     ';'c-y(t)8     ';'c-y(t)9     ';'c-y(t)10    ';
        'c-y(t)11    ';'c-y(t)12    ';'c-y(t)13    ';'c-y(t)14    ';'c-y(t)15    ';'c-y(t)16    ';'c-y(t)17    ';'c-y(t)18    ';'c-y(t)19    ';'c-y(t)20    ';
        'c-y(t)21    ';'c-y(t)22    ';'c-y(t)23    ';'c-y(t)24    ';'c-y(t)25    ';'c-y(t)26    ';'c-y(t)27    ';'c-y(t)28    ';'c-y(t)29    ';'c-y(t)30    ';
        'c-y(t)31    ';'c-y(t)32    ';'c-y(t)33    ';'c-y(t)34    ';'c-y(t)35    ';'c-y(t)36    ';'c-y(t)37    ';'c-y(t)38    ';'c-y(t)39    ';'c-y(t)40    ';
        'c-y(t)41    ';'c-y(t)42    ';'c-y(t)43    ';'c-y(t)44    ';'c-y(t)45    ';'c-y(t)46    ';'c-y(t)47    ';'c-y(t)48    ';'c-y(t)49    ';'c-y(t)50    ';
        'c-y(t)51    ';'c-y(t)52    ';'c-y(t)53    ';'c-y(t)54    ';'c-y(t)55    ';'c-y(t)56    ';'c-y(t)57    ';'c-y(t)58    ';'c-y(t)59    ';'c-y(t)60    ';
        'c-y(t)61    ';'c-y(t)62    ';'c-y(t)63    ';'c-y(t)64    ';'c-y(t)65    ';'c-y(t)66    ';'c-y(t)67    ';'c-y(t)68    ';'c-y(t)69    ';'logy        ';
        'logp        ';'educ        ';'W*logy      ';'W*y(t)      '];        

init1 = ['y(t-1)      ';'Wy(t-1)     ';
         'c-y(t-1)1   ';'c-y(t-1)2   ';'c-y(t-1)3   ';'c-y(t-1)4   ';'c-y(t-1)5   ';'c-y(t-1)6   ';'c-y(t-1)7   ';'c-y(t-1)8   ';'c-y(t-1)9   ';'c-y(t-1)10  ';
         'c-y(t-1)11  ';'c-y(t-1)12  ';'c-y(t-1)13  ';'c-y(t-1)14  ';'c-y(t-1)15  ';'c-y(t-1)16  ';'c-y(t-1)17  ';'c-y(t-1)18  ';'c-y(t-1)19  ';'c-y(t-1)20  ';
         'c-y(t-1)21  ';'c-y(t-1)22  ';'c-y(t-1)23  ';'c-y(t-1)24  ';'c-y(t-1)25  ';'c-y(t-1)26  ';'c-y(t-1)27  ';'c-y(t-1)28  ';'c-y(t-1)29  ';'c-y(t-1)30  ';
         'c-y(t-1)31  ';'c-y(t-1)32  ';'c-y(t-1)33  ';'c-y(t-1)34  ';'c-y(t-1)35  ';'c-y(t-1)36  ';'c-y(t-1)37  ';'c-y(t-1)38  ';'c-y(t-1)39  ';'c-y(t-1)40  ';
         'c-y(t-1)41  ';'c-y(t-1)42  ';'c-y(t-1)43  ';'c-y(t-1)44  ';'c-y(t-1)45  ';'c-y(t-1)46  ';'c-y(t-1)47  ';'c-y(t-1)48  ';'c-y(t-1)49  ';'c-y(t-1)50  ';
         'c-y(t-1)51  ';'c-y(t-1)52  ';'c-y(t-1)53  ';'c-y(t-1)54  ';'c-y(t-1)55  ';'c-y(t-1)56  ';'c-y(t-1)57  ';'c-y(t-1)58  ';'c-y(t-1)59  ';'c-y(t-1)60  ';
         'c-y(t-1)61  ';'c-y(t-1)62  ';'c-y(t-1)63  ';'c-y(t-1)64  ';'c-y(t-1)65  ';'c-y(t-1)66  ';'c-y(t-1)67  ';'c-y(t-1)68  ';'c-y(t-1)69  ';'logy        ';
         'logp        ';'educ        ';'W*logy      ';'W*y(t)      '];

%
% Add M2 if interested.
%

%
% Table 1: Column M3
%
     
results=sar_jihai(y(1:nobs),[yx(N+1:end,1:N) x(N+1:end,:) wx(N+1:end,1)],W,info);
resultats = [results.theta results.theta1 results.tstat1];
[nr,~]    = size(resultats)                             ;
resul     = resultats(1:nr-1,:)                         ;
disp('Yu, de Jong and Lee (2008) ')
disp('(B-C means Bias-Corrected) ')
disp(' ')
disp('            Not B-C      B-C    t-stats')
disp([init,num2str(resul,'% 10.4f')])
disp(' ')
initstat=['R-squared   ';'R2 corrected';'LogL uncor  ';'LogLcorr    ';'sigma2      ';'sigma2 BC   '];
statistics=[results.rsqr results.corr2 results.lik results.lik1 results.theta(end) results.theta1(end)]'; 
disp([initstat,num2str(statistics,'% 15.4f')])
res= results.respaul1;
disp(' ')
n=N;
CD(res,N,T-1,W);
y_ni      = reshape(res,n,T-1)'              ;
R         = corrcoef(y_ni) - diag(ones(n,1)) ;
rho_h_ij  = sum(sum(triu(R))')               ;
rho_h_bar = (2/(n*(n-1)))*rho_h_ij         ;
CD_stat   = sqrt(((T-1)*n*(n-1))/2)*rho_h_bar;
disp('Cross-Sectional Dependence (residuals)')
disp(['rho_hat_bar         ',num2str(rho_h_bar,'% 10.3f')])
disp(['CD statistic        ',num2str(CD_stat,'% 10.3f')])

btemp=results.theta1;
[npar dummy]=size(btemp);
varcov=results.varcov;
tau = results.theta1(1,1);
eta = results.theta1(2,1);
rho = results.theta1(npar-1,1);
varcov=results.varcov;
R=zeros(1,1);
R(1)=tau+rho+eta-1;
Rafg=zeros(1,npar);
Rafg(1,1)=1;Rafg(1,2)=1;Rafg(1,npar-1)=1;
sumpar=tau+rho+eta;
check=tau+rho+eta-1; % this should be negative
Wald=R(1)'*inv(Rafg(1,:)*varcov*Rafg(1,:)')*R(1);
F1=1-chis_cdf (Wald,1);
[sumpar check Wald F1]
VarR1=varcov(1,1)+varcov(2,2)+varcov(npar-1,npar-1)+varcov(1,2)+varcov(2,1)+...
      varcov(1,npar-1)+varcov(npar-1,1)+varcov(2,npar-1)+varcov(npar-1,2);
tval=R(1)/sqrt(VarR1)
R=zeros(1,1);
R(1)=btemp(2)+btemp(1)*btemp(npar-1);
Rafg=zeros(1,npar);
Rafg(1,1)=btemp(npar-1);Rafg(1,2)=1;Rafg(1,npar-1)=btemp(1);
Wald3=R(1)'*inv(Rafg(1,:)*varcov*Rafg(1,:)')*R(1);
F3=1-chis_cdf (Wald3,1);
[R(1) Wald3 F3]
%
% Direct and indirect effects estimates
% st=short term, lt=long term
% c=(long term) convergence effect of dependent variable
%
% Direct and indirect effects estimates
% st=short term, lt=long term
% c=(long term) convergence effect of dependent variable
%
btemp=results.theta1([1,2,72:76]);
varcov=results.varcov([1,2,72:76],[1,2,72:76]);
NSIM=1000;
px=3;
[npar dummy]=size(btemp);
simresults=zeros(npar,NSIM);
simdirst=zeros(px,NSIM);
simindst=zeros(px,NSIM);
simtotst=zeros(px,NSIM);
simdirlt=zeros(px,NSIM);
simindlt=zeros(px,NSIM);
simtotlt=zeros(px,NSIM);
simdirc=zeros(1,NSIM);
simindc=zeros(1,NSIM);
simtotc=zeros(1,NSIM);
for sim=1:NSIM
    parms = chol(varcov)'*randn(size(btemp)) + btemp;
    deltasim = parms(npar,1); % coef WY(t)
    betasim = parms(3:npar-1,1);
    tausim = parms(1,1); % Coef Y(t-1)
    etasim = parms(2,1); % Coef WY(t-1)
    simresults(:,sim)=[tausim;etasim;betasim;deltasim];
    SS=(eye(N)-deltasim*W)\eye(N);
    SC=SS*((tausim-1)*eye(N)+(deltasim+etasim)*W);
    simdirc(1,sim)=sum(diag(SC))/N; % average direct effect
    simindc(1,sim)=sum(sum(SC,2)-diag(SC))/N; % average indirect effect
    simtotc(1,sim)=simdirc(1,sim)+simindc(1,sim);
    for p=1:px
        C=zeros(N,N);
        for i=1:N
            for j=1:N
                if (i==j) C(i,j)=betasim(p);
                elseif (p<2) C(i,j)=betasim(p+px)*W(i,j);
                else C(i,j)=0;
                end
            end
        end
        SC=SS*C;
        simdirst(p,sim)=sum(diag(SC))/N; % average direct effect
        simindst(p,sim)=sum(sum(SC,2)-diag(SC))/N; % average indirect effect
        simtotst(p,sim)=simdirst(p,sim)+simindst(p,sim);
        SC=((1-tausim)*eye(N)-(deltasim+etasim)*W)\C;
        simdirlt(p,sim)=sum(diag(SC))/N; % average direct effect
        simindlt(p,sim)=sum(sum(SC,2)-diag(SC))/N; % average indirect effect
        simtotlt(p,sim)=simdirlt(p,sim)+simindlt(p,sim);        
    end
end
[mean(simresults,2) mean(simresults,2)./std(simresults,0,2)]
fprintf(1,'Convergence effect \n');
[mean(simdirc,2) mean(simdirc,2)./std(simdirc,0,2) mean(simindc,2) mean(simindc,2)./std(simindc,0,2)...
    mean(simtotc,2) mean(simtotc,2)./std(simtotc,0,2)]
fprintf(1,'Short term effects \n');
[mean(simdirst,2) mean(simdirst,2)./std(simdirst,0,2) mean(simindst,2) mean(simindst,2)./std(simindst,0,2)...
    mean(simtotst,2) mean(simtotst,2)./std(simtotst,0,2)]
fprintf(1,'Long term effects \n');
[mean(simdirlt,2) mean(simdirlt,2)./std(simdirlt,0,2) mean(simindlt,2) mean(simindlt,2)./std(simindlt,0,2)...
    mean(simtotlt,2) mean(simtotlt,2)./std(simtotlt,0,2)]

%
% Table 1: Column M4
%

results=sar_jihai(y(1:nobs),[yx(1:end-N,1:N) x(N+1:end,:) wx(N+1:end,1)],W,info);
resultats = [results.theta results.theta1 results.tstat1];
[nr,~]    = size(resultats)                             ;
resul     = resultats(1:nr-1,:)                         ;
disp('Yu, de Jong and Lee (2008) ')
disp('(B-C means Bias-Corrected) ')
disp(' ')
disp('            Not B-C      B-C    t-stats')
disp([init1,num2str(resul,'% 10.4f')])
disp(' ')
initstat=['R-squared   ';'R2 corrected';'LogL uncor  ';'LogLcorr    ';'sigma2      ';'sigma2 BC   '];
statistics=[results.rsqr results.corr2 results.lik results.lik1 results.theta(end) results.theta1(end)]'; 
disp([initstat,num2str(statistics,'% 15.4f')])
res= results.respaul1;
CD(res,N,T-1,W);
disp(' ')
n=N;
y_ni      = reshape(res,n,T-1)'              ;
R         = corrcoef(y_ni) - diag(ones(n,1)) ;
rho_h_ij  = sum(sum(triu(R))')               ;
rho_h_bar = (2/(n*(n-1)))*rho_h_ij         ;
CD_stat   = sqrt(((T-1)*n*(n-1))/2)*rho_h_bar;
disp('Cross-Sectional Dependence (residuals)')
disp(['rho_hat_bar         ',num2str(rho_h_bar,'% 10.3f')])
disp(['CD statistic        ',num2str(CD_stat,'% 10.3f')])

btemp=results.theta1;
[npar dummy]=size(btemp);
varcov=results.varcov;
tau = results.theta1(1,1);
eta = results.theta1(2,1);
rho = results.theta1(npar-1,1);
varcov=results.varcov;
R=zeros(1,1);
R(1)=tau+rho+eta-1;
Rafg=zeros(1,npar);
Rafg(1,1)=1;Rafg(1,2)=1;Rafg(1,npar-1)=1;
sumpar=tau+rho+eta;
check=tau+rho+eta-1; % this should be negative
Wald=R(1)'*inv(Rafg(1,:)*varcov*Rafg(1,:)')*R(1);
F1=1-chis_cdf (Wald,1);
[sumpar check Wald F1]
VarR1=varcov(1,1)+varcov(2,2)+varcov(npar-1,npar-1)+varcov(1,2)+varcov(2,1)+...
      varcov(1,npar-1)+varcov(npar-1,1)+varcov(2,npar-1)+varcov(npar-1,2);
tval=R(1)/sqrt(VarR1)
R=zeros(1,1);
R(1)=btemp(2)+btemp(1)*btemp(npar-1);
Rafg=zeros(1,npar);
Rafg(1,1)=btemp(npar-1);Rafg(1,2)=1;Rafg(1,npar-1)=btemp(1);
Wald3=R(1)'*inv(Rafg(1,:)*varcov*Rafg(1,:)')*R(1);
F3=1-chis_cdf (Wald3,1);
[R(1) Wald3 F3]
%
% Direct and indirect effects estimates
% st=short term, lt=long term
% c=(long term) convergence effect of dependent variable
%
% Direct and indirect effects estimates
% st=short term, lt=long term
% c=(long term) convergence effect of dependent variable
%
btemp=results.theta1([1,2,72:76]);
varcov=results.varcov([1,2,72:76],[1,2,72:76]);
NSIM=1000;
px=3;
[npar dummy]=size(btemp);
simresults=zeros(npar,NSIM);
simdirst=zeros(px,NSIM);
simindst=zeros(px,NSIM);
simtotst=zeros(px,NSIM);
simdirlt=zeros(px,NSIM);
simindlt=zeros(px,NSIM);
simtotlt=zeros(px,NSIM);
simdirc=zeros(1,NSIM);
simindc=zeros(1,NSIM);
simtotc=zeros(1,NSIM);
for sim=1:NSIM
    parms = chol(varcov)'*randn(size(btemp)) + btemp;
    deltasim = parms(npar,1); % coef WY(t)
    betasim = parms(3:npar-1,1);
    tausim = parms(1,1); % Coef Y(t-1)
    etasim = parms(2,1); % Coef WY(t-1)
    simresults(:,sim)=[tausim;etasim;betasim;deltasim];
    SS=(eye(N)-deltasim*W)\eye(N);
    SC=SS*((tausim-1)*eye(N)+(deltasim+etasim)*W);
    simdirc(1,sim)=sum(diag(SC))/N; % average direct effect
    simindc(1,sim)=sum(sum(SC,2)-diag(SC))/N; % average indirect effect
    simtotc(1,sim)=simdirc(1,sim)+simindc(1,sim);
    for p=1:px
        C=zeros(N,N);
        for i=1:N
            for j=1:N
                if (i==j) C(i,j)=betasim(p);
                elseif (p<2) C(i,j)=betasim(p+px)*W(i,j);
                else C(i,j)=0;
                end
            end
        end
        SC=SS*C;
        simdirst(p,sim)=sum(diag(SC))/N; % average direct effect
        simindst(p,sim)=sum(sum(SC,2)-diag(SC))/N; % average indirect effect
        simtotst(p,sim)=simdirst(p,sim)+simindst(p,sim);
        SC=((1-tausim)*eye(N)-(deltasim+etasim)*W)\C;
        simdirlt(p,sim)=sum(diag(SC))/N; % average direct effect
        simindlt(p,sim)=sum(sum(SC,2)-diag(SC))/N; % average indirect effect
        simtotlt(p,sim)=simdirlt(p,sim)+simindlt(p,sim);        
    end
end
[mean(simresults,2) mean(simresults,2)./std(simresults,0,2)]
fprintf(1,'Convergence effect \n');
[mean(simdirc,2) mean(simdirc,2)./std(simdirc,0,2) mean(simindc,2) mean(simindc,2)./std(simindc,0,2)...
    mean(simtotc,2) mean(simtotc,2)./std(simtotc,0,2)]
fprintf(1,'Short term effects \n');
[mean(simdirst,2) mean(simdirst,2)./std(simdirst,0,2) mean(simindst,2) mean(simindst,2)./std(simindst,0,2)...
    mean(simtotst,2) mean(simtotst,2)./std(simtotst,0,2)]
fprintf(1,'Long term effects \n');
[mean(simdirlt,2) mean(simdirlt,2)./std(simdirlt,0,2) mean(simindlt,2) mean(simindlt,2)./std(simindlt,0,2)...
    mean(simtotlt,2) mean(simtotlt,2)./std(simtotlt,0,2)]

%
% Table 1: Column M5 with common factors for y and x, though only at time t.
%
init = ['y(t-1)      ';'Wy(t-1)     ';
        'c-y(t)1     ';'c-y(t)2     ';'c-y(t)3     ';'c-y(t)4     ';'c-y(t)5     ';'c-y(t)6     ';'c-y(t)7     ';'c-y(t)8     ';'c-y(t)9     ';'c-y(t)10    ';
        'c-y(t)11    ';'c-y(t)12    ';'c-y(t)13    ';'c-y(t)14    ';'c-y(t)15    ';'c-y(t)16    ';'c-y(t)17    ';'c-y(t)18    ';'c-y(t)19    ';'c-y(t)20    ';
        'c-y(t)21    ';'c-y(t)22    ';'c-y(t)23    ';'c-y(t)24    ';'c-y(t)25    ';'c-y(t)26    ';'c-y(t)27    ';'c-y(t)28    ';'c-y(t)29    ';'c-y(t)30    ';
        'c-y(t)31    ';'c-y(t)32    ';'c-y(t)33    ';'c-y(t)34    ';'c-y(t)35    ';'c-y(t)36    ';'c-y(t)37    ';'c-y(t)38    ';'c-y(t)39    ';'c-y(t)40    ';
        'c-y(t)41    ';'c-y(t)42    ';'c-y(t)43    ';'c-y(t)44    ';'c-y(t)45    ';'c-y(t)46    ';'c-y(t)47    ';'c-y(t)48    ';'c-y(t)49    ';'c-y(t)50    ';
        'c-y(t)51    ';'c-y(t)52    ';'c-y(t)53    ';'c-y(t)54    ';'c-y(t)55    ';'c-y(t)56    ';'c-y(t)57    ';'c-y(t)58    ';'c-y(t)59    ';'c-y(t)60    ';
        'c-y(t)61    ';'c-y(t)62    ';'c-y(t)63    ';'c-y(t)64    ';'c-y(t)65    ';'c-y(t)66    ';'c-y(t)67    ';'c-y(t)68    ';'c-y(t)69    ';'c-xt1-1     ';
        'c-xt1-2     ';'c-xt1-3     ';'c-xt1-4     ';'c-xt1-5     ';'c-xt1-6     ';'c-xt1-7     ';'c-xt1-8     ';'c-xt1-9     ';'c-xt1-10    ';'c-xt1-11    ';
        'c-xt1-12    ';'c-xt1-13    ';'c-xt1-14    ';'c-xt1-15    ';'c-xt1-16    ';'c-xt1-17    ';'c-xt1-18    ';'c-xt1-19    ';'c-xt1-20    ';'c-xt1-21    ';
        'c-xt1-22    ';'c-xt1-23    ';'c-xt1-24    ';'c-xt1-25    ';'c-xt1-26    ';'c-xt1-27    ';'c-xt1-28    ';'c-xt1-29    ';'c-xt1-30    ';'c-xt1-31    ';
        'c-xt1-32    ';'c-xt1-33    ';'c-xt1-34    ';'c-xt1-35    ';'c-xt1-36    ';'c-xt1-37    ';'c-xt1-38    ';'c-xt1-39    ';'c-xt1-40    ';'c-xt1-41    ';
        'c-xt1-42    ';'c-xt1-43    ';'c-xt1-44    ';'c-xt1-45    ';'c-xt1-46    ';'c-xt1-47    ';'c-xt1-48    ';'c-xt1-49    ';'c-xt1-50    ';'c-xt1-51    ';
        'c-xt1-52    ';'c-xt1-53    ';'c-xt1-54    ';'c-xt1-55    ';'c-xt1-56    ';'c-xt1-57    ';'c-xt1-58    ';'c-xt1-59    ';'c-xt1-60    ';'c-xt1-61    ';
        'c-xt1-62    ';'c-xt1-63    ';'c-xt1-64    ';'c-xt1-65    ';'c-xt1-66    ';'c-xt1-67    ';'c-xt1-68    ';'c-xt1-69    ';'c-xt2-1     ';'c-xt2-2     ';
        'c-xt2-3     ';'c-xt2-4     ';'c-xt2-5     ';'c-xt2-6     ';'c-xt2-7     ';'c-xt2-8     ';'c-xt2-9     ';'c-xt2-10    ';'c-xt2-11    ';'c-xt2-12    ';
        'c-xt2-13    ';'c-xt2-14    ';'c-xt2-15    ';'c-xt2-16    ';'c-xt2-17    ';'c-xt2-18    ';'c-xt2-19    ';'c-xt2-20    ';'c-xt2-21    ';'c-xt2-22    ';
        'c-xt2-23    ';'c-xt2-24    ';'c-xt2-25    ';'c-xt2-26    ';'c-xt2-27    ';'c-xt2-28    ';'c-xt2-29    ';'c-xt2-30    ';'c-xt2-31    ';'c-xt2-32    ';
        'c-xt2-33    ';'c-xt2-34    ';'c-xt2-35    ';'c-xt2-36    ';'c-xt2-37    ';'c-xt2-38    ';'c-xt2-39    ';'c-xt2-40    ';'c-xt2-41    ';'c-xt2-42    ';
        'c-xt2-43    ';'c-xt2-44    ';'c-xt2-45    ';'c-xt2-46    ';'c-xt2-47    ';'c-xt2-48    ';'c-xt2-49    ';'c-xt2-50    ';'c-xt2-51    ';'c-xt2-52    ';
        'c-xt2-53    ';'c-xt2-54    ';'c-xt2-55    ';'c-xt2-56    ';'c-xt2-57    ';'c-xt2-58    ';'c-xt2-59    ';'c-xt2-60    ';'c-xt2-61    ';'c-xt2-62    ';
        'c-xt2-63    ';'c-xt2-64    ';'c-xt2-65    ';'c-xt2-66    ';'c-xt2-67    ';'c-xt2-68    ';'c-xt2-69    ';'c-xt3-1     ';'c-xt3-2     ';'c-xt3-3     ';
        'c-xt3-4     ';'c-xt3-5     ';'c-xt3-6     ';'c-xt3-7     ';'c-xt3-8     ';'c-xt3-9     ';'c-xt3-10    ';'c-xt3-11    ';'c-xt3-12    ';'c-xt3-13    ';
        'c-xt3-14    ';'c-xt3-15    ';'c-xt3-16    ';'c-xt3-17    ';'c-xt3-18    ';'c-xt3-19    ';'c-xt3-20    ';'c-xt3-21    ';'c-xt3-22    ';'c-xt3-23    ';
        'c-xt3-24    ';'c-xt3-25    ';'c-xt3-26    ';'c-xt3-27    ';'c-xt3-28    ';'c-xt3-29    ';'c-xt3-30    ';'c-xt3-31    ';'c-xt3-32    ';'c-xt3-33    ';
        'c-xt3-34    ';'c-xt3-35    ';'c-xt3-36    ';'c-xt3-37    ';'c-xt3-38    ';'c-xt3-39    ';'c-xt3-40    ';'c-xt3-41    ';'c-xt3-42    ';'c-xt3-43    ';
        'c-xt3-44    ';'c-xt3-45    ';'c-xt3-46    ';'c-xt3-47    ';'c-xt3-48    ';'c-xt3-49    ';'c-xt3-50    ';'c-xt3-51    ';'c-xt3-52    ';'c-xt3-53    ';
        'c-xt3-54    ';'c-xt3-55    ';'c-xt3-56    ';'c-xt3-57    ';'c-xt3-58    ';'c-xt3-59    ';'c-xt3-60    ';'c-xt3-61    ';'c-xt3-62    ';'c-xt3-63    ';
        'c-xt3-64    ';'c-xt3-65    ';'c-xt3-66    ';'c-xt3-67    ';'c-xt3-68    ';'c-xt3-69    ';'logy        ';'logp        ';'educ        ';'W*logy      ';
        'W*y(t)      '];
results=sar_jihai(y(1:nobs),[yx(N+1:end,1:N) x1(N+1:end,1:N) x2(N+1:end,1:N) x3(N+1:end,1:N) x(N+1:end,:) wx(N+1:end,1)],W,info);
resultats = [results.theta results.theta1 results.tstat1];
[nr,~]    = size(resultats)                             ;
resul     = resultats(1:nr-1,:)                         ;
disp('Yu, de Jong and Lee (2008) ')
disp('(B-C means Bias-Corrected) ')
disp(' ')
disp('            Not B-C      B-C    t-stats')
disp([init,num2str(resul,'% 10.4f')])
disp(' ')
initstat=['R-squared   ';'R2 corrected';'LogL uncor  ';'LogLcorr    ';'sigma2      ';'sigma2 BC   '];
statistics=[results.rsqr results.corr2 results.lik results.lik1 results.theta(end) results.theta1(end)]'; 
disp([initstat,num2str(statistics,'% 15.4f')])
res= results.respaul1;
CD(res,N,T-1,W);
disp(' ')
n=N;
y_ni      = reshape(res,n,T-1)'              ;
R         = corrcoef(y_ni) - diag(ones(n,1)) ;
rho_h_ij  = sum(sum(triu(R))')               ;
rho_h_bar = (2/(n*(n-1)))*rho_h_ij         ;
CD_stat   = sqrt(((T-1)*n*(n-1))/2)*rho_h_bar;
disp('Cross-Sectional Dependence (residuals)')
disp(['rho_hat_bar         ',num2str(rho_h_bar,'% 10.3f')])
disp(['CD statistic        ',num2str(CD_stat,'% 10.3f')])

btemp=results.theta1;
[npar dummy]=size(btemp);
varcov=results.varcov;
tau = results.theta1(1,1);
eta = results.theta1(2,1);
rho = results.theta1(npar-1,1);
varcov=results.varcov;
R=zeros(1,1);
R(1)=tau+rho+eta-1;
Rafg=zeros(1,npar);
Rafg(1,1)=1;Rafg(1,2)=1;Rafg(1,npar-1)=1;
sumpar=tau+rho+eta;
check=tau+rho+eta-1; % this should be negative
Wald=R(1)'*inv(Rafg(1,:)*varcov*Rafg(1,:)')*R(1);
F1=1-chis_cdf (Wald,1);
[sumpar check Wald F1]
VarR1=varcov(1,1)+varcov(2,2)+varcov(npar-1,npar-1)+varcov(1,2)+varcov(2,1)+...
      varcov(1,npar-1)+varcov(npar-1,1)+varcov(2,npar-1)+varcov(npar-1,2);
tval=R(1)/sqrt(VarR1)
R=zeros(1,1);
R(1)=btemp(2)+btemp(1)*btemp(npar-1);
Rafg=zeros(1,npar);
Rafg(1,1)=btemp(npar-1);Rafg(1,2)=1;Rafg(1,npar-1)=btemp(1);
Wald3=R(1)'*inv(Rafg(1,:)*varcov*Rafg(1,:)')*R(1);
F3=1-chis_cdf (Wald3,1);
[R(1) Wald3 F3]

btemp=results.theta1([1,2,279:283]);
varcov=results.varcov([1,2,279:283],[1,2,279:283]);
NSIM=1000;
px=3;
[npar dummy]=size(btemp);
simresults=zeros(npar,NSIM);
simdirst=zeros(px,NSIM);
simindst=zeros(px,NSIM);
simtotst=zeros(px,NSIM);
simdirlt=zeros(px,NSIM);
simindlt=zeros(px,NSIM);
simtotlt=zeros(px,NSIM);
simdirc=zeros(1,NSIM);
simindc=zeros(1,NSIM);
simtotc=zeros(1,NSIM);
for sim=1:NSIM
    parms = chol(varcov)'*randn(size(btemp)) + btemp;
    deltasim = parms(npar,1); % coef WY(t)
    betasim = parms(3:npar-1,1);
    tausim = parms(1,1); % Coef Y(t-1)
    etasim = parms(2,1); % Coef WY(t-1)
    simresults(:,sim)=[tausim;etasim;betasim;deltasim];
    SS=(eye(N)-deltasim*W)\eye(N);
    SC=SS*((tausim-1)*eye(N)+(deltasim+etasim)*W);
    simdirc(1,sim)=sum(diag(SC))/N; % average direct effect
    simindc(1,sim)=sum(sum(SC,2)-diag(SC))/N; % average indirect effect
    simtotc(1,sim)=simdirc(1,sim)+simindc(1,sim);
    for p=1:px
        C=zeros(N,N);
        for i=1:N
            for j=1:N
                if (i==j) C(i,j)=betasim(p);
                elseif (p<2) C(i,j)=betasim(p+px)*W(i,j);
                else C(i,j)=0;
                end
            end
        end
        SC=SS*C;
        simdirst(p,sim)=sum(diag(SC))/N; % average direct effect
        simindst(p,sim)=sum(sum(SC,2)-diag(SC))/N; % average indirect effect
        simtotst(p,sim)=simdirst(p,sim)+simindst(p,sim);
        SC=((1-tausim)*eye(N)-(deltasim+etasim)*W)\C;
        simdirlt(p,sim)=sum(diag(SC))/N; % average direct effect
        simindlt(p,sim)=sum(sum(SC,2)-diag(SC))/N; % average indirect effect
        simtotlt(p,sim)=simdirlt(p,sim)+simindlt(p,sim);        
    end
end
[mean(simresults,2) mean(simresults,2)./std(simresults,0,2)]
fprintf(1,'Convergence effect \n');
[mean(simdirc,2) mean(simdirc,2)./std(simdirc,0,2) mean(simindc,2) mean(simindc,2)./std(simindc,0,2)...
    mean(simtotc,2) mean(simtotc,2)./std(simtotc,0,2)]
fprintf(1,'Short term effects \n');
[mean(simdirst,2) mean(simdirst,2)./std(simdirst,0,2) mean(simindst,2) mean(simindst,2)./std(simindst,0,2)...
    mean(simtotst,2) mean(simtotst,2)./std(simtotst,0,2)]
fprintf(1,'Long term effects \n');
[mean(simdirlt,2) mean(simdirlt,2)./std(simdirlt,0,2) mean(simindlt,2) mean(simindlt,2)./std(simindlt,0,2)...
    mean(simtotlt,2) mean(simtotlt,2)./std(simtotlt,0,2)]
%
% Table 1: Column M6
%

%
% Check what happens if common factors are included
% at time t and t-1.
%
init = ['y(t-1)      ';'Wy(t-1)     ';
        'c-y(t)1     ';'c-y(t)2     ';'c-y(t)3     ';'c-y(t)4     ';'c-y(t)5     ';'c-y(t)6     ';'c-y(t)7     ';'c-y(t)8     ';'c-y(t)9     ';'c-y(t)10    ';
        'c-y(t)11    ';'c-y(t)12    ';'c-y(t)13    ';'c-y(t)14    ';'c-y(t)15    ';'c-y(t)16    ';'c-y(t)17    ';'c-y(t)18    ';'c-y(t)19    ';'c-y(t)20    ';
        'c-y(t)21    ';'c-y(t)22    ';'c-y(t)23    ';'c-y(t)24    ';'c-y(t)25    ';'c-y(t)26    ';'c-y(t)27    ';'c-y(t)28    ';'c-y(t)29    ';'c-y(t)30    ';
        'c-y(t)31    ';'c-y(t)32    ';'c-y(t)33    ';'c-y(t)34    ';'c-y(t)35    ';'c-y(t)36    ';'c-y(t)37    ';'c-y(t)38    ';'c-y(t)39    ';'c-y(t)40    ';
        'c-y(t)41    ';'c-y(t)42    ';'c-y(t)43    ';'c-y(t)44    ';'c-y(t)45    ';'c-y(t)46    ';'c-y(t)47    ';'c-y(t)48    ';'c-y(t)49    ';'c-y(t)50    ';
        'c-y(t)51    ';'c-y(t)52    ';'c-y(t)53    ';'c-y(t)54    ';'c-y(t)55    ';'c-y(t)56    ';'c-y(t)57    ';'c-y(t)58    ';'c-y(t)59    ';'c-y(t)60    ';
        'c-y(t)61    ';'c-y(t)62    ';'c-y(t)63    ';'c-y(t)64    ';'c-y(t)65    ';'c-y(t)66    ';'c-y(t)67    ';'c-y(t)68    ';'c-y(t)69    ';'c-y(t-1)1   ';
        'c-y(t-1)2   ';'c-y(t-1)3   ';'c-y(t-1)4   ';'c-y(t-1)5   ';'c-y(t-1)6   ';'c-y(t-1)7   ';'c-y(t-1)8   ';'c-y(t-1)9   ';'c-y(t-1)10  ';'c-y(t-1)11  ';
        'c-y(t-1)12  ';'c-y(t-1)13  ';'c-y(t-1)14  ';'c-y(t-1)15  ';'c-y(t-1)16  ';'c-y(t-1)17  ';'c-y(t-1)18  ';'c-y(t-1)19  ';'c-y(t-1)20  ';'c-y(t-1)21  ';
        'c-y(t-1)22  ';'c-y(t-1)23  ';'c-y(t-1)24  ';'c-y(t-1)25  ';'c-y(t-1)26  ';'c-y(t-1)27  ';'c-y(t-1)28  ';'c-y(t-1)29  ';'c-y(t-1)30  ';'c-y(t-1)31  ';
        'c-y(t-1)32  ';'c-y(t-1)33  ';'c-y(t-1)34  ';'c-y(t-1)35  ';'c-y(t-1)36  ';'c-y(t-1)37  ';'c-y(t-1)38  ';'c-y(t-1)39  ';'c-y(t-1)40  ';'c-y(t-1)41  ';
        'c-y(t-1)42  ';'c-y(t-1)43  ';'c-y(t-1)44  ';'c-y(t-1)45  ';'c-y(t-1)46  ';'c-y(t-1)47  ';'c-y(t-1)48  ';'c-y(t-1)49  ';'c-y(t-1)50  ';'c-y(t-1)51  ';
        'c-y(t-1)52  ';'c-y(t-1)53  ';'c-y(t-1)54  ';'c-y(t-1)55  ';'c-y(t-1)56  ';'c-y(t-1)57  ';'c-y(t-1)58  ';'c-y(t-1)59  ';'c-y(t-1)60  ';'c-y(t-1)61  ';
        'c-y(t-1)62  ';'c-y(t-1)63  ';'c-y(t-1)64  ';'c-y(t-1)65  ';'c-y(t-1)66  ';'c-y(t-1)67  ';'c-y(t-1)68  ';'c-y(t-1)69  ';'logy        ';'logp        ';
        'educ        ';'W*logy      ';'W*y(t)      '];
results=sar_jihai(y(1:nobs),[yx(N+1:end,1:N) yx(1:end-N,1:N) x(N+1:end,:) wx(N+1:end,1)],W,info);
resultats = [results.theta results.theta1 results.tstat1];
[nr,~]    = size(resultats)                             ;
resul     = resultats(1:nr-1,:)                         ;
disp('Yu, de Jong and Lee (2008) ')
disp('(B-C means Bias-Corrected) ')
disp(' ')
disp('            Not B-C      B-C    t-stats')
disp([init,num2str(resul,'% 10.4f')])
disp(' ')
initstat=['R-squared   ';'R2 corrected';'LogL uncor  ';'LogLcorr    ';'sigma2      ';'sigma2 BC   '];
statistics=[results.rsqr results.corr2 results.lik results.lik1 results.theta(end) results.theta1(end)]'; 
disp([initstat,num2str(statistics,'% 15.4f')])
res= results.respaul1;
CD(res,N,T-1,W);
disp(' ')
n=N;
y_ni      = reshape(res,n,T-1)'              ;
R         = corrcoef(y_ni) - diag(ones(n,1)) ;
rho_h_ij  = sum(sum(triu(R))')               ;
rho_h_bar = (2/(n*(n-1)))*rho_h_ij         ;
CD_stat   = sqrt(((T-1)*n*(n-1))/2)*rho_h_bar;
disp('Cross-Sectional Dependence (residuals)')
disp(['rho_hat_bar         ',num2str(rho_h_bar,'% 10.3f')])
disp(['CD statistic        ',num2str(CD_stat,'% 10.3f')])

btemp=results.theta1;
[npar dummy]=size(btemp);
varcov=results.varcov;
tau = results.theta1(1,1);
eta = results.theta1(2,1);
rho = results.theta1(npar-1,1);
varcov=results.varcov;
R=zeros(1,1);
R(1)=tau+rho+eta-1;
Rafg=zeros(1,npar);
Rafg(1,1)=1;Rafg(1,2)=1;Rafg(1,npar-1)=1;
sumpar=tau+rho+eta;
check=tau+rho+eta-1; % this should be negative
Wald=R(1)'*inv(Rafg(1,:)*varcov*Rafg(1,:)')*R(1);
F1=1-chis_cdf (Wald,1);
[sumpar check Wald F1]
VarR1=varcov(1,1)+varcov(2,2)+varcov(npar-1,npar-1)+varcov(1,2)+varcov(2,1)+...
      varcov(1,npar-1)+varcov(npar-1,1)+varcov(2,npar-1)+varcov(npar-1,2);
tval=R(1)/sqrt(VarR1)
R=zeros(1,1);
R(1)=btemp(2)+btemp(1)*btemp(npar-1);
Rafg=zeros(1,npar);
Rafg(1,1)=btemp(npar-1);Rafg(1,2)=1;Rafg(1,npar-1)=btemp(1);
Wald3=R(1)'*inv(Rafg(1,:)*varcov*Rafg(1,:)')*R(1);
F3=1-chis_cdf (Wald3,1);
[R(1) Wald3 F3]

btemp=results.theta1([1,2,141:145]);
varcov=results.varcov([1,2,141:145],[1,2,141:145]);
NSIM=1000;
px=3;
[npar dummy]=size(btemp);
simresults=zeros(npar,NSIM);
simdirst=zeros(px,NSIM);
simindst=zeros(px,NSIM);
simtotst=zeros(px,NSIM);
simdirlt=zeros(px,NSIM);
simindlt=zeros(px,NSIM);
simtotlt=zeros(px,NSIM);
simdirc=zeros(1,NSIM);
simindc=zeros(1,NSIM);
simtotc=zeros(1,NSIM);
for sim=1:NSIM
    parms = chol(varcov)'*randn(size(btemp)) + btemp;
    deltasim = parms(npar,1); % coef WY(t)
    betasim = parms(3:npar-1,1);
    tausim = parms(1,1); % Coef Y(t-1)
    etasim = parms(2,1); % Coef WY(t-1)
    simresults(:,sim)=[tausim;etasim;betasim;deltasim];
    SS=(eye(N)-deltasim*W)\eye(N);
    SC=SS*((tausim-1)*eye(N)+(deltasim+etasim)*W);
    simdirc(1,sim)=sum(diag(SC))/N; % average direct effect
    simindc(1,sim)=sum(sum(SC,2)-diag(SC))/N; % average indirect effect
    simtotc(1,sim)=simdirc(1,sim)+simindc(1,sim);
    for p=1:px
        C=zeros(N,N);
        for i=1:N
            for j=1:N
                if (i==j) C(i,j)=betasim(p);
                elseif (p<2) C(i,j)=betasim(p+px)*W(i,j);
                else C(i,j)=0;
                end
            end
        end
        SC=SS*C;
        simdirst(p,sim)=sum(diag(SC))/N; % average direct effect
        simindst(p,sim)=sum(sum(SC,2)-diag(SC))/N; % average indirect effect
        simtotst(p,sim)=simdirst(p,sim)+simindst(p,sim);
        SC=((1-tausim)*eye(N)-(deltasim+etasim)*W)\C;
        simdirlt(p,sim)=sum(diag(SC))/N; % average direct effect
        simindlt(p,sim)=sum(sum(SC,2)-diag(SC))/N; % average indirect effect
        simtotlt(p,sim)=simdirlt(p,sim)+simindlt(p,sim);        
    end
end
[mean(simresults,2) mean(simresults,2)./std(simresults,0,2)]
fprintf(1,'Convergence effect \n');
[mean(simdirc,2) mean(simdirc,2)./std(simdirc,0,2) mean(simindc,2) mean(simindc,2)./std(simindc,0,2)...
    mean(simtotc,2) mean(simtotc,2)./std(simtotc,0,2)]
fprintf(1,'Short term effects \n');
[mean(simdirst,2) mean(simdirst,2)./std(simdirst,0,2) mean(simindst,2) mean(simindst,2)./std(simindst,0,2)...
    mean(simtotst,2) mean(simtotst,2)./std(simtotst,0,2)]
fprintf(1,'Long term effects \n');
[mean(simdirlt,2) mean(simdirlt,2)./std(simdirlt,0,2) mean(simindlt,2) mean(simindlt,2)./std(simindlt,0,2)...
    mean(simtotlt,2) mean(simtotlt,2)./std(simtotlt,0,2)]
