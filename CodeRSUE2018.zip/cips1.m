function results=cips1(Y,N,T)
% Y is an T by N matrix
disp(' ')
meany=mean(Y,2); 
dmeany=meany(2:T)-meany(1:T-1);
nvar=5;
tvar=zeros(N,5);
best=zeros(N,5);
yesno=zeros(N,5);
for i=1:N
    y=zeros(T-1,1);
    x=zeros(T-1,nvar);
    for t=1:T-1
        y(t)=Y(t+1,i)-Y(t,i);
        x(t,1)=1;
        x(t,2)=Y(t,i);
        x(t,3)=meany(t);
        x(t,4)=dmeany(t);
        x(t,5)=t; %trend
    end
    x1=[x(:,1) x(:,2) x(:,5)]; % only trend
    x2=[x(:,1) x(:,2) x(:,3)];
    x3=[x(:,1) x(:,2) x(:,4)];
    x4=[x(:,1) x(:,2) x(:,3) x(:,4)];
    x5=[x(:,1) x(:,2)];

    X=x1;   
    b=inv(X'*X)*X'*y;
    si2=((y-X*b)'*(y-X*b))/(T-1);
    var=diag(si2*inv(X'*X));
    best(i,1)=b(2);
    tvar(i,1)=b(2)/sqrt(var(2));
    if (tvar(i,1)>-2.75 ) yesno(i,1)=1; end % 95
%   if (tvar(i,2)>-2.5 ) yesno(i,2)=1; end % 90
    
    X=x2;   
    b=inv(X'*X)*X'*y;
    si2=((y-X*b)'*(y-X*b))/(T-1);
    var=diag(si2*inv(X'*X));
    best(i,2)=b(2);
    tvar(i,2)=b(2)/sqrt(var(2));
    if (tvar(i,2)>-2.75 ) yesno(i,2)=1; end % 95

    X=x3;   
    b=inv(X'*X)*X'*y;
    si2=((y-X*b)'*(y-X*b))/(T-1);
    var=diag(si2*inv(X'*X));
    best(i,3)=b(2);
    tvar(i,3)=b(2)/sqrt(var(2));
    if (tvar(i,3)>-2.75 ) yesno(i,3)=1; end % 95
    
    X=x4;   
    b=inv(X'*X)*X'*y;
    si2=((y-X*b)'*(y-X*b))/(T-1);
    var=diag(si2*inv(X'*X));
    best(i,4)=b(2);
    tvar(i,4)=b(2)/sqrt(var(2));
    if (tvar(i,4)>-2.75 ) yesno(i,4)=1; end % 95

    X=x5;   
    b=inv(X'*X)*X'*y;
    si2=((y-X*b)'*(y-X*b))/(T-1);
    var=diag(si2*inv(X'*X));
    best(i,5)=b(2);
    tvar(i,5)=b(2)/sqrt(var(2));
    if (tvar(i,5)>-2.75 ) yesno(i,5)=1; end % 95
    
end
best
tvar
[N mean(tvar)]
[N sum(yesno)]
 end