 function results=cips(Y,N,T)
% Y is an T by N matrix
disp(' ')
%meany=zeros(T,1);
%dmeany=zeros(T-1,1);
meany=mean(Y,2); 
dmeany=meany(2:T)-meany(1:T-1);
nvar=4;
bols=zeros(N,nvar);
tvar=zeros(N,nvar);
yesno=zeros(N,2);
for i=1:N
    y=zeros(T-1,1);
    x=zeros(T-1,nvar);
    for t=1:T-1
        y(t)=Y(t+1,i)-Y(t,i);
        x(t,1)=1;
        x(t,2)=Y(t,i);
        x(t,3)=meany(t);
        x(t,4)=dmeany(t);
    end
    b=inv(x'*x)*x'*y;
    bols(i,:)=b';
    si2=((y-x*b)'*(y-x*b))/(T-1);
    var=diag(si2*inv(x'*x));
    tvar(i,:)=b./sqrt(var);
    if (tvar(i,2)>-2.75 ) yesno(i,1)=1; end % 95
    if (tvar(i,2)>-2.5 ) yesno(i,2)=1; end % 90
end
[mean(tvar(:,2)) N sum(yesno)]
end
