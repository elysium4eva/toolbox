function results=cips2(Y,X,N,T)
% Y is an T by N matrix
% X is an NT by K matrix, which needs to be transformed in different blocks
% of T by N for each explanatory variable
disp(' ')
meany=mean(Y,2); 
K=cols(X);
meanx=zeros(T,K);
for k=1:K
    xhelp=reshape(X(:,k),N,T)'; % Now is T by N
    meanx(:,k)=mean(xhelp,2);
end
tvar=zeros(N,1);
best=zeros(N,1);
yesno=zeros(N,1);
for i=1:N
    y=zeros(T-1,1);
    x=zeros(T-1,1);
    for t=1:T-1
        y(t)=Y(t+1,i)-Y(t,i);
        x(t,1)=1;
        x(t,2)=Y(t,i);
        x(t,3)=meany(t);
        for k=1:K
            x(t,3+k)=meanx(t,k);
        end
    end
    X=x;   
    b=inv(X'*X)*X'*y;
    si2=((y-X*b)'*(y-X*b))/(T-1);
    var=diag(si2*inv(X'*X));
    best(i,1)=b(2);
    tvar(i,1)=b(2)/sqrt(var(2));
    if (tvar(i,1)>-2.75 ) yesno(i,1)=1; end % 95
%   if (tvar(i,2)>-2.5 ) yesno(i,2)=1; end % 90
   
end
best
tvar
[N mean(tvar)]
[N sum(yesno)]
 end